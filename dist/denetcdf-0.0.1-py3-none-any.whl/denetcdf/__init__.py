from netCDF4 import Dataset, date2num
import numpy as np

